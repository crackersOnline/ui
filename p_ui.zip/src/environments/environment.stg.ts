// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: false,
    envName: 'stg',
    oAuthClientId: 'PavoNonProd',
    oAuthClientSecret: 'lblLMJHhiIXMgeptzYFrPKMtJRr0CmkDX3qYoaIfEARwwWkvc1s5IfTtQGkqwzH2',
    oAuthUrl: 'https://fss.stg.inbcu.com/fss/as/authorization.oauth2',
    oAuthLogoutUrl: 'https://login.stg.inbcu.com/login/logoff.jsp',
    oAuthTokenUrl: 'https://fss.stg.inbcu.com/fss/as/token.oauth2',
    oAuthRevokeTokenUrl: 'https://fss.stg.inbcu.com/fss/as/revoke_token.oauth2',
    oAuthGrantsUrl: 'https://fss.stg.inbcu.com/fss/as/oauth_access_grants.ping',
    oAuthRedirctUrl: 'https://pavo-stg.inbcu.com/',
    gatewayBaseUrl: 'https://pavo-stg.inbcu.com/api/',
    searchBaseUrl: 'https://pavo-stg.inbcu.com/api/',
    userMgmtBaseUrl: 'https://pavo-stg.inbcu.com/api/',
    apiBaseUrl: 'https://pavo-stg.inbcu.com/api/',
    constants: {
      copyright: '© 2020 NBCUNIVERSAL MEDIA, LLC',
      env: 'stg',
      appVersion: '1.0',
      mailto: 'peacockhubdevsupport@nbcuni.com',
      appSupportmailbody: 'https://pavo-stg.inbcu.com',
      dataSciencemailbody: 'https://pavo-stg.inbcu.com'
    },
    reportLinkBaseUrl: 'https://peacockinsights.inbcu.com/t/Peacock/views/'
  };

  /*
   * For easier debugging in development mode, you can import the following file
   * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
   *
   * This import should be commented out in production mode because it will have a negative impact
   * on performance if an error is thrown.
   */
  // import 'zone.js/dist/zone-error';  // Included with Angular CLI.
