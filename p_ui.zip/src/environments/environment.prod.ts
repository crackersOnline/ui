export const environment = {
  production: true,
  envName: 'production',
  oAuthClientId: 'PavoProd',
  oAuthClientSecret: 'sIz9NJwerNARpXjLGzwdosJq0yiOD9v8Qbv5zI2xdtqS0Wug8nFx3LnACyzD6lR9',
  oAuthUrl: 'https://fss.inbcu.com/fss/as/authorization.oauth2',
  oAuthLogoutUrl: 'https://login.inbcu.com/login/logoff.jsp',
  oAuthTokenUrl: 'https://fss.inbcu.com/fss/as/token.oauth2',
  oAuthRevokeTokenUrl: 'https://fss.inbcu.com/fss/as/revoke_token.oauth2',
  oAuthGrantsUrl: 'https://fss.inbcu.com/fss/as/oauth_access_grants.ping',
  oAuthRedirctUrl: 'https://pavo.inbcu.com/',
  userMgmtBaseUrl: 'https://pavo.inbcu.com/api/',
  searchBaseUrl: 'https://pavo.inbcu.com/api/',
  gatewayBaseUrl: 'https://pavo.inbcu.com/api/',
  apiBaseUrl: 'https://pavo.inbcu.com/api/',
  constants: {
    copyright: '© 2020 NBCUNIVERSAL MEDIA, LLC',
    env: 'Production',
    appVersion: '1.0',
    mailto: 'peacockhubdevsupport@nbcuni.com',
    appSupportmailbody: 'https://pavo.inbcu.com',
    dataSciencemailbody: 'https://pavo.inbcu.com'
  },
  reportLinkBaseUrl: 'https://peacockinsights.inbcu.com/t/Peacock/views/'
};
