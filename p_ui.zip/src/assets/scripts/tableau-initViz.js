/**
 * @method: initViz()
 * @param: { url, container }
 * @returns: {}
 * @description: function gets tableau url and html element where to add the iframe
 */

function initViz() {
console.log('-- initViz');
    // var containerDiv = document.getElementsByTagName('app-root').item(0).getElementsByTagName('div').item(0),
    var containerDiv = document.getElementById("vizContainer"),
    // url = "https://MY-SERVER/views/ABCPrototypev1/ByXYZ",
    // url = "https://public.tableau.com/views/USTreasuryInterestRate/Sheet1?:embed=y&:display_count=yes",
    url = "https://sharedtableaudev2.inbcu.com/#/site/FacilitiesAnalytics/views/Superstore/Shipping?:iid=1",
    options = {
      height: 800,
      width: 1000,
      hideTabs: true,
      onFirstInteractive: function () {
        console.log("Run this code when the viz has finished loading.");
      }
    };

    if(viz != null) {
      viz.dispose();
    }
  
    var viz = new tableau.Viz(containerDiv, url, options);
    // Create a viz object and embed it in the container div.
}