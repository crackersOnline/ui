import { TestBed } from '@angular/core/testing';

import { TableauViewService } from './tableau-view.service';

describe('TableauViewService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TableauViewService = TestBed.get(TableauViewService);
    expect(service).toBeTruthy();
  });
});
