/* eslint-disable */
declare var initViz: any;
declare var tableau: any;
import { DeviceDetectorService } from 'ngx-device-detector';
import { MetdataService } from './../common/common.module';
import { Injectable } from '@angular/core';

enum tableauDeviceTypes {
  phone = 'phone',
  tablet = 'tablet',
  desktop = 'desktop'
}

enum deviceWidth {
  phone = 375,
  tablet = 768,
  desktop = 1300
}

enum tableauHeight {
  phone = 3000,
  tablet = 1927,
  desktop = 1300,
}

enum kpiSpecificHeight {
  phone = 1000,
  desktop = 300,
  tablet = 1927,

}
enum tableauWidth {
  phone = 375,
  tablet = 768,
  desktop = 1300
}

@Injectable({
  providedIn: 'root'
})
export class TableauViewService {
  deviceInfo = {};
  constructor(private deviceDetectorService: DeviceDetectorService, private metdataService: MetdataService) {
    this.deviceInfo = this.deviceDetectorService.getDeviceInfo();
    this.deviceInfo['device'] = this.deviceDetectorService.isMobile() ? tableauDeviceTypes.phone
      : this.deviceDetectorService.isTablet() ? tableauDeviceTypes.tablet
        : tableauDeviceTypes.desktop;
  }
  private vizDivMap = [];

  private checkExistanceOfVizAndGetNew(containerDiv) {
    const existingMap = this.vizDivMap.
      find(x => x.div === containerDiv);
    let map: any = {};
    if (existingMap) {
      existingMap.viz.dispose();
      map = existingMap;
    } else {
      map.div = containerDiv;
      map.viz = {};
      this.vizDivMap.push(map);
    }
    return map;
  }

  initViz() {
    const containerDiv = document.getElementById('vizContainer');
    const url = 'https://peacockinsights.inbcu.com/t/Peacock/views/'
      + 'Executive-PrimaryKPIs-PAVOTestFile/Executive-PrimaryKPIs?:showAppBanner=false&:'
      + 'display_count=n&:showVizHome=n&:origin=viz_share_link&:refresh=yes';
    const options = {
      onFirstInteractive() {
        // console.log("Run this code when the viz has finished loading.");
        // setInterval(function () {
        //   viz.refreshDataAsync()
        // }, 15000);  // 15 sec
      },
      width: containerDiv.offsetWidth,
    };
    // Create a viz object and embed it in the container div.
    const map = this.checkExistanceOfVizAndGetNew(containerDiv);
    map.viz = new tableau.Viz(containerDiv, url, options);
  }

  /*
  In Safari, the window.innerWidth property is not working and Desktop View is rendered on mobile too.
      So we need better platform detection including browser.
      For Safari, have a fixed width for each platform :
      Desktop : 1300px
			Tablet :     768px
			Mobile:     375px
  */

  setDeviceAndDimensions(containerDivv: any) {
    const deviceInfo = {};

    /* If deviceInfo is defined and browser is Safari then apply the library to handle Safari browser compatibility issues
    ELSE use window object
    */
   
    if (this.deviceInfo && this.deviceInfo['browser'] === 'Safari') {
      deviceInfo['device'] = this.deviceInfo['device'];

      if (this.deviceInfo['device'] === tableauDeviceTypes.desktop) {
        deviceInfo['width'] = tableauWidth.desktop - 20;
        deviceInfo['height'] = tableauHeight.desktop;
      } else if (this.deviceInfo['device'] === tableauDeviceTypes.tablet) {
        deviceInfo['width'] = tableauWidth.tablet;
        deviceInfo['height'] = tableauHeight.tablet;
      } else {
        deviceInfo['width'] = tableauWidth.phone;
        deviceInfo['height'] = tableauHeight.phone;
      }
    } else {
      if (window.innerWidth > deviceWidth.tablet) {
        deviceInfo['device'] = tableauDeviceTypes.desktop;
        deviceInfo['width'] = containerDivv.offsetWidth - 20;
        deviceInfo['height'] = tableauHeight.desktop;
      } else if (window.innerWidth > deviceWidth.phone) {
        deviceInfo['device'] = tableauDeviceTypes.tablet;
        deviceInfo['width'] = containerDivv.offsetWidth;
        deviceInfo['height'] = tableauHeight.tablet;
      } else {
        deviceInfo['device'] = tableauDeviceTypes.phone;
        deviceInfo['width'] = containerDivv.offsetWidth;
        deviceInfo['height'] = tableauHeight.phone;
      }
    }
    return deviceInfo;
  }

  private configureAndRenderTableauViz(containerDiv: string, url: string, module?: string) {
    const containerDivv = document.getElementById(containerDiv);
    const deviceInfo = this.setDeviceAndDimensions(containerDivv);
    if (module && module === 'KPI' && deviceInfo['device'] !== tableauDeviceTypes.desktop) {
      deviceInfo['device'] = tableauDeviceTypes.phone;
      deviceInfo['width'] = containerDivv.offsetWidth;
    }
    url += `&:device=${deviceInfo['device']}&:refresh=y`;
    const options = {
      width: deviceInfo['width'],
      height: module && module === 'KPI' ? kpiSpecificHeight[deviceInfo['device']] : deviceInfo['height']
    };
    const map = this.checkExistanceOfVizAndGetNew(containerDiv);
    map.viz = new tableau.Viz(containerDivv, url, options);
  }

  loadTableau(containerDiv: string, url: string, module?: string) {
    this.configureAndRenderTableauViz(containerDiv, url, module);
  }

  loadingIndicatorObserver(elem: string) {
    const container = document.querySelector(elem);
    if (container) {
      const observer = new MutationObserver((mutations) => {
        const that = this;
        mutations.forEach((mutation) => {
          this.metdataService.$showSpinner.next(true);
          [].filter.call(mutation.addedNodes, (node) => {
            container.setAttribute('style', 'height:100%');
            return node.nodeName === 'IFRAME';
          }).forEach((node) => {
            node.addEventListener('load', (e) => {
              that.metdataService.$showSpinner.next(false);
              observer.disconnect();
            });
          });
        });
      });

      observer.observe(container, {
        childList: true,
        subtree: true
      });
    }
  }
}
