import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class AppSingletonService {
    public userInfo: any;
    public categoryMasterList: any;
    public ModuleMasterList: any;
    public SubBusinessMasterList: any;
    public CostCentreMasterList: any;


    public setUserInfo(data) {
        this.userInfo = data;
    }
    public getUserInfo() {
        return this.userInfo;
    }

    // Setter and Getter of CategoryMasterList
    public setCategoryMasterList(data) {
        this.categoryMasterList = data;
    }
    public getCategoryMasterList() {
        return this.categoryMasterList;
    }

    // Setter and Getter of ModuleMasterList
    public setModuleMasterList(data) {
        this.ModuleMasterList = data;
    }
    public getModuleMasterList() {
        return this.ModuleMasterList;
    }

    public setSubBusinessMasterList(data) {
        this.SubBusinessMasterList = data;
    }
    public getSubBusinessMasterList() {
        return this.SubBusinessMasterList;
    }

    public setCostCentreMasterList(data) {
        this.CostCentreMasterList = data;
    }
    public getCostCentreMasterList() {
        return this.CostCentreMasterList;
    }
}
