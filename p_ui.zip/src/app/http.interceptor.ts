import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';

import { AppConstantsHelper, JwtTokenService, LoggerService, LogType } from './common/common.module';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {

    constructor(private jwtTokenService: JwtTokenService,
                private loggerService: LoggerService,
                private router: Router) { }

    public setToken(request: HttpRequest<any>): HttpRequest<any> {
        let req: HttpRequest<any>;
        if (AppConstantsHelper.tokenLessRelativeUrls.some(url => request.url.indexOf(url) !== -1)) {
            req = request;
        } else {
            req = request.clone({ headers: request.headers.set('access-token', this.jwtTokenService.getAuthToken()) });
        }
        return req;
    }

    public handleTokenError(req: HttpRequest<any>, next: HttpHandler, error: HttpErrorResponse) {
        this.loggerService.logToServer(LogType.Error, this.prepareLog(req, error));
        return this.getTokenAgain(req, next);
    }

    getTokenAgain(req: HttpRequest<any>, next: HttpHandler) {
        return this.jwtTokenService.getToken()
            .pipe(
                switchMap((newToken: any) => {
                    if (newToken) {
                        this.jwtTokenService.setAuthToken(newToken.token);
                        return next.handle(this.setToken(req));
                    } else {
                        this.router.navigate(['/error']);
                    }
                }));
    }

    prepareLog(request: HttpRequest<any>, error: HttpErrorResponse) {
        return {
            url: request.url,
            methodDetails: { params: request.params, body: request.body },
            methodType: request.method,
            errorDetails: error.error.message,
            errorCode: error.status
        };
    }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(this.setToken(request))
            .pipe(
                catchError((error: any) => {
                    if (error instanceof HttpErrorResponse) {
                        switch ((error as HttpErrorResponse).status) {
                            case 401:
                                this.router.navigate(['/error']);
                                break;
                            case 403:
                                return this.handleTokenError(request, next, error);
                        }
                    }
                    return throwError(error);
                })
            );
    }
}
