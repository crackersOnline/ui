
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Resolve, Router, ActivatedRouteSnapshot } from '@angular/router';
import { AuthService } from './common/services/auth.service';
import { AppSingletonService } from './app.singleton.service';
import { AppConstantsHelper } from './common/helpers/app-constants.helper';
import { environment } from 'src/environments/environment';
import { CommonFunctionsHelper } from './common/common.module';

@Injectable()
export class AuthManager implements Resolve<any> {
    public indexAccessToken: number;
    public indexIdToken: number;
    public indexTokenType: number;
    public stateStr: number;
    public accessTokenStr: string;
    public idTokenStr: string;
    public expiresIn: number;
    public indexExpiresIn: number;
    public expiresInStr = '';
    public userSSO = '-1';
    public userEmail = '';
    public userFirstName = '';
    public userLastName = '';
    public userRole = '';
    public userStatus = '';
    public tokenExpired = false;
    public idToken = '-1';
    public accessTokenIssueDate: Date;
    public currentDate = new Date();
    public baseurl = window.location.origin;
    public referenceUrl: string;
    // buffer for timing out
    public authenticationSubject: Subject<{}> = new Subject<{}>();
    public authenticationObj;
    public accessToken;

    constructor(
        private router: Router,
        private authService: AuthService,
        private singletonService: AppSingletonService) {

        this.authenticationSubject.subscribe((value) => {
            this.authenticationObj = value;
        });
        this.indexAccessToken = window.location.href.indexOf('access_token');
        this.indexTokenType = window.location.href.indexOf('&token_type');
        this.indexIdToken = window.location.href.indexOf('id_token');
        this.stateStr = window.location.href.indexOf('&state');
        this.indexExpiresIn = window.location.href.indexOf('expires_in');
        this.accessTokenStr = 'access_token=';
        this.idTokenStr = 'id_token=';
        this.expiresInStr = 'expires_in=';

        if (localStorage.getItem('id_token')) {
            this.accessTokenIssueDate = new Date(localStorage.getItem('access_token_issuedate'));
            const accessTokenExpiryDateTime = new Date(this.accessTokenIssueDate);
            accessTokenExpiryDateTime.setSeconds(this.accessTokenIssueDate.getSeconds() +
                parseInt(localStorage.getItem('expires_in'), 10));
            if (this.currentDate > accessTokenExpiryDateTime) {
                this.tokenExpired = true;
            }
        }
    }

    public resolve(next: ActivatedRouteSnapshot) {
        if (window.location.href.indexOf('#') !== -1) {
            let queryParams: any = {};
            const search = window.location.href.split('#')[1];
            queryParams = JSON.parse('{"' + decodeURI(search).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g, '":"') + '"}');
            this.idToken = queryParams.id_token;
            this.accessToken = queryParams.access_token;
            this.expiresIn = queryParams.expires_in;
            localStorage.setItem('id_token', this.idToken);
            localStorage.setItem('access_token_issuedate', this.currentDate.toString());
            localStorage.setItem('expires_in', this.expiresIn.toString());
            localStorage.setItem('access_token', this.accessToken);
        }
        if ((!(localStorage.getItem('id_token') || localStorage.getItem('id_token') === 'undefined') &&
            this.userSSO === '-1' && this.indexAccessToken === -1) || this.tokenExpired) {
            localStorage.setItem('referenceUrl', window.location.href);
            this.authService.getOpenIdToken();
        } else if (this.indexAccessToken > -1 && !(localStorage.getItem('id_token'))) {
            const result = this.authService.getDecodedAccessToken(this.idToken);
            if (!this.isValidIDToken(result)) {
                CommonFunctionsHelper.clearLocalStorageForAuth();
                // this.router.navigate(['/error']);
                this.authService.getOpenIdToken();
            } else {
                this.userSSO = result.sub;
                this.getUserInfo();
            }

        } else if (localStorage.getItem('id_token') && !this.tokenExpired && this.userSSO === '-1') {
            // if valid access token exist and user info is not there then get user details only
            const result = this.authService.getDecodedAccessToken(localStorage.getItem('id_token'));
            if (!this.isValidIDToken(result)) {
                CommonFunctionsHelper.clearLocalStorageForAuth();
                // this.router.navigate(['/error']);
                this.authService.getOpenIdToken();
            } else {
                this.userSSO = result.sub;
                this.getUserInfo();
            }
        } else if (this.userSSO === '-1' && !localStorage.getItem('id_token')) {
            this.router.navigate(['']);
        } else {
            this.authenticationSubject.next(this.authenticationObj);
        }
    }

    public getUserInfo() {
        this.authService.getUserDetails(this.userSSO).subscribe(
            (result: any) => {
                if (result.user && result.user !== undefined) {
                    this.userStatus = result.user.UserStatus;
                    this.userFirstName = result.user.FirstName;
                    this.userLastName = result.user.LastName;
                    this.userEmail = result.user.UserEmail;
                    this.userRole = result.user.UserRole;
                }
            },
            error => console.log('Error :: ' + error),
            () => this.setUserInfo(this.userSSO, this.userFirstName, this.userLastName, this.userEmail, this.userRole, this.userStatus)
        );
    }

    private setUserInfo(userSSO, firstName, lastName, eMail, roleId, status) {
        const user = {
            userSSO,
            userName: firstName + ' ' + lastName,
            userEmail: eMail,
            userRole: roleId,
            userStatus: status
        };
        this.authenticationObj = user;
        this.singletonService.setUserInfo(user);
        this.authenticationSubject.next(this.authenticationObj);
        this.makeUsageTrackerAPI();
    }

    private makeUsageTrackerAPI() {
        // const userActions = CommonFunctionsHelper.getUserActions('Login');
        // const userData = CommonFunctionsHelper.prepareUsageTrackingData({
        //     userActions: userActions,
        //     metaDataDetails: { demo: {} },
        //     otherData: {}
        // });
        // this.usageTracking(userData);
    }

    // public usageTracking(data: any) {
    //     this.graphsDataService.logUsageTracking(data);
    // }

    private isValidIDToken(result: any) {
        let isValidIdToken = false;
        if (result.nonce === localStorage.getItem('nonce_key') &&
            result.aud === environment.oAuthClientId) {
            isValidIdToken = true;
        }
        return isValidIdToken;
    }
}
