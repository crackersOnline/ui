import { CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { AppSingletonService } from './app.singleton.service';
import { LoggerService } from './common/services/logger.service';
import { AppConstantsHelper } from './common/helpers/app-constants.helper';
import {  CommonFunctionsHelper } from './common/common.module';

@Injectable()
export class AlwaysAuthGuard implements CanActivate {
  constructor(  private appSingletonService: AppSingletonService,
                private router: Router,
                private loggerService: LoggerService) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    const user = localStorage.getItem('currentUser');
    const routedUrl = state.url.split('/');
    const childRoute = routedUrl[routedUrl.length - 1];
    if (user && user !== undefined) {
      if (childRoute.toLowerCase()  === 'users'
      && JSON.parse(localStorage.getItem('currentUser')).userRole === AppConstantsHelper.userRole) {
        return true;
      } else if (childRoute.toLowerCase() === 'users'
      && JSON.parse(localStorage.getItem('currentUser')).userRole !== AppConstantsHelper.userRole) {
        this.router.navigate(['search']);
      } else {
        this.router.navigate(['error']);
      }
    } else {
      // this.loggerService.logToServer(LogType.Error, AppConstantsHelper.userauthNull);
      this.router.navigate(['error']);
    }
  }
}
