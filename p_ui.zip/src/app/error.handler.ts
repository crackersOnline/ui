import { ErrorHandler, Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { LoggerService } from './common/common.module';

@Injectable()
export class AppErrorHandler implements ErrorHandler {
    handleError(error) {
        if (error instanceof HttpErrorResponse) {
            if ((error as HttpErrorResponse).status === 500) {
                alert(error.message);
            }
        }
        throw error;
    }
}
