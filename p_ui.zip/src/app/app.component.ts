// declare var initViz: any;
import { Component, OnDestroy, OnInit } from '@angular/core';
import { interval, Subscription, forkJoin, Observable } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { environment } from '../environments/environment';
import { AuthManager } from './app.auth.manager';

import {
  MetdataService,
  JwtTokenService,
  DataConstantsHelper,
  AppConstantsHelper,
  AuthService,
  UsageTrackingService,
  UsageTrackingModel,
  UsageTrackingActionType
} from './common/common.module';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnDestroy, OnInit {
  title = 'peacock-insightHub';
  isAuthentication = false;
  isUserAuthZForPavo = true;
  showSpinner = true;
  firstName = '';
  userRole = '';
  public isAdminUser = false;
  showSpinnerObservable: Observable<boolean>;
  private subscription: Subscription;
  public appTabs = DataConstantsHelper.appTabOptions;
  public envConstant: any;
  public leafUrl: any;


  // constructor(public tableauViewService: TableauViewService) { }
  constructor(
    public metadataService: MetdataService,
    private jwtTokenService: JwtTokenService,
    private authManager: AuthManager,
    private authService: AuthService,
    private usageTrackingService: UsageTrackingService,
    private router: Router) {
    metadataService.$showSpinner.asObservable().subscribe(show => {
      this.showSpinner = show;
    });

    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.leafUrl = (event as NavigationEnd).url;
      }
    });
    this.envConstant = environment.constants;
    this.authManager.authenticationSubject.subscribe((params: any) => {
      if (params && params.userSSO) {
        if (params.userSSO !== '-1' && params.userStatus === AppConstantsHelper.userStatus) {
          this.usageTrackingService.log(new UsageTrackingModel(UsageTrackingActionType.Login,
            null,
            null,
            null,
            null));
          this.isAuthentication = true;
          this.firstName = params.userName;
          this.userRole = params.userRole;
          if (this.userRole === AppConstantsHelper.userRole) {
            this.isAdminUser = true;
          }
          localStorage.setItem('currentUser', JSON.stringify(params));
          localStorage.setItem(AppConstantsHelper.loggedInUser, params.userSSO);
          if (!this.metadataService.metdataRecieved) {
            this.metadataService.$showSpinner.next(true);
            this.jwtTokenService.getToken().subscribe((results: any) => {
              setTimeout(() => {
                this.metadataService.$showSpinner.next(false);
              }, 1000);
              this.jwtTokenService.setAuthToken(results.token);
              this.metadataService.notifyMetaDataRecieved();
              if (router.url.indexOf('#') !== -1) {
                const url = router.url.substring(0, router.url.indexOf('#'));
                router.navigateByUrl(url);
              }
            });
          } else {
            this.metadataService.notifyMetaDataRecieved();
          }
        } else {
          this.isUserAuthZForPavo = false;
          this.showSpinner = false;
        }
      }
    });
    // router.events.subscribe((val) => {
    //   this.setSelectedTab({ path: window.location.href }, null);
    // });
  }

  ngOnInit() {

  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  setSelectedTab(selectedTab, event) {
    if (event) {
      event.stopPropagation();
    }
    this.appTabs.forEach(tab => {
      tab.isSelected = tab.path ? selectedTab.path.indexOf(tab.path) !== -1 : false;
    });
  }

  logout() {
    this.authService.logoutUser();
    this.usageTrackingService.log(new UsageTrackingModel(UsageTrackingActionType.LogOff,
      null,
      null,
      null,
      null));
  }

}


