import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeviceDetectorModule } from 'ngx-device-detector';
export { CSVHelper } from './helpers/csv.helper';
export { AppConstantsHelper } from './helpers/app-constants.helper';
export { CommonFunctionsHelper } from './helpers/common-functions.helper';
export { DataConstantsHelper } from './helpers/data-constants.helper';
export { MetdataService } from './services/metdata.service';
export { LoggerService } from './services/logger.service';
export { JwtTokenService } from './services/jwtToken.service';
export { AuthService } from './services/auth.service';
export { UsageTrackingService } from './services/usage-tracking.service';
export { LogType, ReportTypeEnum, UsageTrackingActionType } from './models/app.enums';
export { UserMetadata } from './models/user.model';
export { UsageTrackingModel } from './models/usage-tracking.model';
import { SelectCheckAllComponent } from './../modules/admin/users/select-check-all.component';
import {
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatInputModule,
    MatListModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule
  } from '@angular/material';
import { FormsModule , ReactiveFormsModule} from '@angular/forms';

@NgModule({
    declarations: [  ],
    imports: [CommonModule,
      DeviceDetectorModule.forRoot(),
      FormsModule,
      ReactiveFormsModule,
      MatSelectModule,
      MatListModule,
      MatButtonModule,
      MatCheckboxModule],
    providers: [],
    exports: []
})
export class CommonProjectModule {
}
