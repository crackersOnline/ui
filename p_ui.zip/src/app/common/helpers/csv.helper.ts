import { ExportToCsv } from 'export-to-csv';
import { Observable } from 'rxjs';



export class CSVHelper {
    private static options = {
        fieldSeparator: ',',
        quoteStrings: '"',
        decimalSeparator: '.',
        showLabels: true,
        useTextFile: false,
        useBom: true,
        useKeysAsHeaders: true,
        // headers: ['Column 1', 'Column 2', etc...] <-- Won't work with useKeysAsHeaders present!
    };
    public static downloadCSV(data) {
        const csvExporter = new ExportToCsv(this.options);
        csvExporter.generateCsv(data);
    }
}
