import { Injectable } from '@angular/core';
import { DeviceDetectorService } from 'ngx-device-detector';
import { DeviceType } from '../models/app.enums';
import { AppSettings } from 'src/app/app.settings';
import { ApiProxy } from 'src/app/api.proxy';
@Injectable({
    providedIn: 'root'
})
export class UsageTrackingService {
    private url: string = AppSettings.microservices.Gateway_MicroService_BaseUrl;
    constructor(private deviceDetectorService: DeviceDetectorService, private apiProxy: ApiProxy) { }
    public log(data) {
        data.platform = this.deviceDetectorService.isMobile() ? DeviceType.phone
            : this.deviceDetectorService.isTablet() ? DeviceType.tablet : DeviceType.desktop;
        this.apiProxy.post(this.url + 'usageTrack/save', data).subscribe(x => { });
    }
}
