import { Injectable } from '@angular/core';
import { ApiProxy } from '../../api.proxy';
import { AppSettings } from '../../app.settings';
import { AppConstantsHelper } from '../helpers/app-constants.helper';
import { Observable, BehaviorSubject, from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class JwtTokenService {

  private baseUrl: string = AppSettings.microservices.Gateway_MicroService_BaseUrl;

  constructor(private apiProxy: ApiProxy) { }

  public getToken() {
    const data = this.setParamsAsPerTheEnviornment();
    return this.apiProxy.post(this.baseUrl + 'jwt/token', data);
  }

  public setParamsAsPerTheEnviornment() {
    const tokenParams: any = {};
    // tokenParams.sso = localStorage.getItem(AppConstantsHelper.loggedInUser);
    tokenParams.sso = localStorage.getItem(AppConstantsHelper.loggedInUser);
    tokenParams.role = 'ADMIN';
    tokenParams.issuer = 'PAVO_UI';
    return tokenParams;
  }

  public setAuthToken(token) {
    localStorage.setItem(AppConstantsHelper.jwtToken, token);
  }

  public getAuthToken() {
    return localStorage.getItem(AppConstantsHelper.jwtToken);
  }

}
