
import { Injectable } from '@angular/core';
import { ApiProxy } from '../../api.proxy';
import { AppSettings } from '../../app.settings';
import { LogType } from '../models/app.enums';

@Injectable({
  providedIn: 'root'
})
export class LoggerService {

  private baseUrl = AppSettings.microservices.Gateway_MicroService_BaseUrl;
  constructor(private apiProxy: ApiProxy) { }

  public startAuditLog(event: string) {
    const logObj = {
      event,
      startTime: new Date()
    };
    console.log(event + ' | Start Time:' + logObj.startTime);
    return logObj;
  }

  public endAuditLog(logObj: any) {
    const endTime = new Date();
    const diffTime = Math.abs(endTime.getTime() - logObj.startTime.getTime());
    console.log(logObj.event + ' | End Time:' + endTime + ',' + (diffTime) + 'ms');
  }

  public logToServer(type: LogType, data: any) {
    data.details = type + ' | ' + data.details;
    return this.apiProxy.post(this.baseUrl + 'logToServer' , data);
  }

}
