import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { AppConstantsHelper } from '../helpers/app-constants.helper';

@Injectable({
  providedIn: 'root'
})
export class MetdataService {
  private $metadata: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private $metadataChange: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public $showSpinner: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public metadataObservable = this.$metadata.asObservable();
  public showSpinner = false;
  public metdataRecieved = false;
  public metadataChangeObservable = this.$metadataChange.asObservable();

  constructor() { }

  public notifyMetaDataRecieved() {
    this.metdataRecieved = true;
    this.$metadata.next(true);
  }

  public notifyMetaDataChanged(isReady: boolean) {
    this.$metadataChange.next(isReady);
  }

  public saveLoggedInUserData(data) {
    localStorage.setItem(AppConstantsHelper.loggedInUser, data);
  }

}
