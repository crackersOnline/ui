import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../common/services/auth.service';
import { environment } from '../../../../environments/environment';
@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.scss']
})
export class ErrorComponent implements OnInit {
  public heights;
  public envConstant: any;
  constructor(private authService: AuthService) {
    this.heights = {
      section: window.innerHeight - 280
    };
    this.envConstant = environment.constants;
  }
  public ngOnInit() { /** Nothing to do */}
  public logout() {
    this.authService.logoutUser();
  }
}
