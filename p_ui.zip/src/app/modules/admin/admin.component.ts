import { Component, OnInit } from '@angular/core';
import { DataConstantsHelper, CommonFunctionsHelper, MetdataService } from '../../common/common.module';
import { Router } from '@angular/router';
import { AppSingletonService } from './../../app.singleton.service';
import { UsersService } from './users/users.service';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html'
})

export class AdminComponent implements OnInit {

  public selectedTab;
  public reqParamsForSubTabs: any;
  constructor() {
  }

  ngOnInit() {}
}
