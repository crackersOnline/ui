import { Component, EventEmitter, Output, } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { CreateEditUserComponent } from '../create-edit-user/create-edit-user.component';
import { Router } from '@angular/router';
// import { AppConstantsHelper } from '../../../common/common.module';
import { UsersService } from 'src/app/modules/admin/users/users.service';
import { DeleteDialogComponent } from '../../../../fragments/core/delete-dialog/delete-dialog.component';

@Component({
  selector: 'app-user-button-action',
  template: `
      <mat-icon (click)="editUser()">edit</mat-icon>
      <mat-icon (click)="deleteUser()">delete_forever</mat-icon>`,
  styles: [
    `.mat-icon {
      color: gray;
      font-size: 20px;
    }
    `
  ]
})

export class UserButtonActionComponent {

  public params: any;

  simpleDialog: MatDialogRef<CreateEditUserComponent>;
  confirmDialog: MatDialogRef<DeleteDialogComponent>;
  // @Output() onEditUserClick: EventEmitter<any> = new EventEmitter<any>();

  constructor(private dialogModel: MatDialog,
              private router: Router,
              private usersService: UsersService) {

  }

  agInit(params: any): void {
    this.params = params;
  }

  editUser() {
    this.simpleDialog = this.dialogModel.open(CreateEditUserComponent, {
      data: { isUpdate: true, userData: JSON.parse(JSON.stringify(this.params.data)) },
      disableClose: false
    });

    this.simpleDialog.afterClosed().subscribe((result: any) => {
      this.simpleDialog = null;
      if (result !== 'cancel') {
        this.router.navigate(['/admin/users']);
      }
    });
  }

  deleteUser() {
    this.confirmDialog = this.dialogModel.open(DeleteDialogComponent, {
      data: { title : 'Delete User', description: 'To delete the user, click the OK button' },
      disableClose: false,
      role: 'alertdialog'
    });

    this.confirmDialog.afterClosed().subscribe((dialogResult: boolean) => {
      if (dialogResult === true) {
        this.usersService.deleteUser({SSO: this.params.data.UserSSO}).subscribe(
          (response: any) => {
              if (response.RecordCount > 0) {
                this.confirmDialog = null;
              }
          });
        this.router.navigate(['/admin/users']);
      }
    });
  }

}

