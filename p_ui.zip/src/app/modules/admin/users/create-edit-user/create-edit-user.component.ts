import { Component, OnInit, Inject, ViewChild, Input, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { UsersService } from './../users.service';
import { AppSingletonService } from 'src/app/app.singleton.service';
import { AppConstantsHelper, CommonFunctionsHelper, UserMetadata } from '../../../../common/common.module';

@Component({
  selector: 'app-create-edit-user',
  templateUrl: './create-edit-user.component.html',
  styleUrls: ['./create-edit-user.component.scss']
})
export class CreateEditUserComponent implements OnInit {

  isUpdate = false;
  public invalidResult = {
    sso: false,
    firstName: false,
    emailID: false,
    emailIDFormat: false,
    duplicateSSO: false,
    duplicateEmailID: false,
    ssoLength: false,
    lastName: false
  };
  saveDisabled = false;
  allCategories: any;
  allModules: any;
  allSubBusiness: any;
  allCostCentre: any;

  selected = [];
  selectedItem = [];

  selectedCategory = [];
  selectedModules = [];
  userEditDetails;

  pavoUserStatus = AppConstantsHelper.pavoUserStatus;
  pavoRoles = AppConstantsHelper.pavoRoles;
  selectedStatus: any;
  selectedRoles: any;
  selectedSubBusiness: any;
  selectedCostCenter: any;
  userData: any;
  loggedInUserSSO: any;

  @ViewChild('categoryInput', {static: false}) categorySelectBox: any;
  @ViewChild('moduleInput', {static: false}) moduleSelectBox: any;

  constructor(private dialogRef: MatDialogRef<CreateEditUserComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private usersService: UsersService,
              private singletonService: AppSingletonService) {
    this.isUpdate = this.data.isUpdate;
    this.userEditDetails = this.data.userData;
    this.userData = this.data.entireUserData;
  }

  ngOnInit() {

    this.allCategories = this.singletonService.getCategoryMasterList();
    this.allModules = this.singletonService.getModuleMasterList();

    this.allSubBusiness = this.singletonService.getSubBusinessMasterList();
    this.allCostCentre = this.singletonService.getCostCentreMasterList();
    this.loggedInUserSSO = localStorage.getItem(AppConstantsHelper.loggedInUser);
    CommonFunctionsHelper.sortArrayBasedOnAStringValuedProp(this.allSubBusiness, 'Description', 'asc');
    CommonFunctionsHelper.sortArrayBasedOnAStringValuedProp(this.allCostCentre, 'Description', 'asc');

    if (this.isUpdate === false) {
      this.selectedRoles = this.pavoRoles.filter((role) => {
        return role.isSelected === true;
      })[0];
      this.selectedStatus = this.pavoUserStatus.filter((status) => {
        return status.isSelected === true;
      })[0];

      this.userEditDetails = new UserMetadata('', '', '', '', '', '', this.selectedRoles.name, this.selectedStatus.name,
        this.loggedInUserSSO, this.loggedInUserSSO);
      this.userEditDetails.UserStatus = this.selectedStatus.name;
      this.userEditDetails.UserRole = this.selectedRoles.name;
      this.selectedCategory = this.allCategories;
      this.selectedModules = this.allModules;
      this.selectedSubBusiness = this.allCostCentre[0];
      this.userEditDetails.subBusiness = this.selectedSubBusiness.ID;

      this.selectedCostCenter =  this.allSubBusiness[0];
      this.userEditDetails.costCenter = this.selectedCostCenter.ID;

    } else {
      this.selectedRoles = this.pavoRoles.filter((role) => {
        return role.name === this.userEditDetails.UserRole;
      })[0];

      if (this.selectedRoles) {
       this.userEditDetails.UserRole =  this.selectedRoles.name;
      }
      this.selectedStatus = this.pavoUserStatus.filter((status) => {
        return status.name === this.userEditDetails.UserStatus;
      })[0];
      if (this.selectedStatus) {
        this.userEditDetails.UserStatus = this.selectedStatus.name;
      }

      this.selectedSubBusiness = this.allSubBusiness.filter((sub) => {
        return sub.ID === parseInt(this.userEditDetails.SubBusinessID, 10);
      })[0];
      if (this.selectedSubBusiness) {
        this.userEditDetails.subBusiness = this.selectedSubBusiness.ID;
      } else {
        this.userEditDetails.subBusiness = 0 ;
      }

      this.selectedCostCenter = this.allCostCentre.filter((cost) => {
        return cost.ID === parseInt(this.userEditDetails.CostCentreID, 10);
      })[0];

      if (this.selectedCostCenter) {
        this.userEditDetails.costCenter = this.selectedCostCenter.ID;
      } else {
        this.userEditDetails.costCenter = 0;
      }
    }
    if (typeof (this.userEditDetails.UserCategories) !== 'undefined') {
      const currentUserCategories = JSON.parse(this.userEditDetails.UserCategories);
      if (currentUserCategories !== null) {

        if (JSON.parse(this.userEditDetails.UserCategories).Categories[0] === 0 ) {
          this.selectedCategory = this.allCategories;
        } else  {
        this.selectedCategory = this.allCategories.filter(cat => {
          return currentUserCategories.Categories.indexOf(cat.ID) > -1;
        });
        }
      }
    }

    if (typeof (this.userEditDetails.UserModules) !== 'undefined') {
      const currentUserModules = JSON.parse(this.userEditDetails.UserModules);
      if (currentUserModules !== null) {
        if (JSON.parse(this.userEditDetails.UserModules).Modules[0] === 0 ) {
          this.selectedModules = this.allModules;
        } else  {
        this.selectedModules = this.allModules.filter(mod => {
          return currentUserModules.Modules.indexOf(mod.ID) > -1;
        });
        }
      }
    }
  }

  close(event?) {
    this.dialogRef.close(event);
  }

  onCloseCategory() {
    this.categorySelectBox.close();
  }

  onApplyCategory() {
    this.categorySelectBox.close();
  }

  onCloseModules() {
    this.moduleSelectBox.close();
  }

  onApplyModules() {
    this.moduleSelectBox.close();
  }

  checkForValidation(e, firstname, sso, email, lastname) {

    if (!this.isUpdate) {
      if (sso.toString().trim() === '') {
        this.invalidResult.sso = true;
      } else {
        if (sso.toString().length !== 9) {
          this.invalidResult.ssoLength = true;
        } else {
          this.invalidResult.ssoLength = false;
          this.invalidResult.sso = false;
          if (this.userData !== undefined) {
            const ssoExist = this.userData.filter((user) => {
              return user.UserSSO === this.userEditDetails.UserSSO.toString();
            });
            if (ssoExist.length > 0) {
              this.invalidResult.duplicateSSO = true;
            } else {
              this.invalidResult.duplicateSSO = false;
            }
          }
        }
      }
    }
    if (email.toString().trim() === '') {
      this.invalidResult.emailID = true;
    } else {
      this.invalidResult.emailID = false;
      const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
      const isEmailValid = emailPattern.test(email);
      this.invalidResult.emailIDFormat = !isEmailValid;
    }

    if (firstname.toString().trim() === '') {
      this.invalidResult.firstName = true;
    } else {
      this.invalidResult.firstName = false;
    }

    if (lastname.toString().trim() === '') {
      this.invalidResult.lastName = true;
    } else {
      this.invalidResult.lastName = false;
    }


    if (this.invalidResult.sso || this.invalidResult.firstName || this.invalidResult.emailID ||
      this.invalidResult.duplicateEmailID || this.invalidResult.duplicateSSO || this.invalidResult.emailIDFormat ||
      this.invalidResult.ssoLength || this.invalidResult.lastName || (this.selectedCategory.length === 0) || (this.selectedModules.length === 0)) {
      this.saveDisabled = true;
      event.preventDefault();
    } else {
      this.updateUser();
    }

  }


  alphabetsOnly(event) {
    const pattern = /^[a-zA-Z ]*$/;
    const charCode = (event.which) ? event.which : event.keyCode;
    const inputChar = String.fromCharCode(charCode);

    if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      return false;
    }
  }

  isNumber(evt) {
    evt = (evt) ? evt : window.event;
    let charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
  }

  updateUser() {
    const catIDs = [];
    const moduleIDS = [];

    if (this.selectedCategory === this.allCategories) {
      catIDs.push(0);
    } else {
      for (const key in this.selectedCategory) {
        catIDs.push(this.selectedCategory[key].ID);
      }
    }

    const cat = {
      'Categories': catIDs
    };


    if (this.selectedModules === this.allModules) {
      moduleIDS.push(0);
    } else {
      for (const key in this.selectedModules) {
        moduleIDS.push(this.selectedModules[key].ID);
      }
    }
    const mod = {
      'Modules': moduleIDS
    };

    const editData = {
      'FirstName': this.userEditDetails.FirstName,
      'LastName': this.userEditDetails.LastName,
      'EmailID': this.userEditDetails.UserEmail,
      'CreatedBy': this.loggedInUserSSO,
      'UpdatedBy': this.loggedInUserSSO,
      'UserRole': this.userEditDetails.UserRole,
      'UserStatus': this.userEditDetails.UserStatus,
      'SSO': this.userEditDetails.UserSSO,
      'UserCategories': cat,
      'UserModules': mod,
      'SubBusinessID': this.userEditDetails.subBusiness,
      'CostCentreID' : this.userEditDetails.costCenter
    };

    if (this.isUpdate) {
      this.usersService.updateUserData(editData).subscribe(
        (response: any) => {
          if (response.RecordCount > 0) {
            this.close();
          }
        });
    } else {
      this.usersService.createUserData(editData).subscribe(
        (response: any) => {
          if (response.RecordCount > 0) {
            this.close();
          }
        });
    }
  }
}
