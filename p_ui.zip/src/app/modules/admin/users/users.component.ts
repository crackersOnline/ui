
import { Component, OnDestroy, OnInit, Input } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Subject, Subscription } from 'rxjs';
import { AppSingletonService } from 'src/app/app.singleton.service';
import { DownloadTypeEnum } from 'src/app/common/models/app.enums';
import { AppConstantsHelper, CommonFunctionsHelper, MetdataService } from '../../../common/common.module';
import { CreateEditUserComponent } from '../../admin/users/create-edit-user/create-edit-user.component';
import { UsersService } from './users.service';
import { UserButtonActionComponent} from './user-button-action/user-button-action.component';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html'
})
export class UsersComponent implements OnInit, OnDestroy {

  simpleDialog: MatDialogRef<CreateEditUserComponent>;
  modalRef: BsModalRef;
  public userData;
  public userHeaderDefs = [
    {
        headerName: 'SSO', field: 'UserSSO', sortable: true, filter: true,
        cellClass: 'editable-cell', autoHeight: true,
        cellStyle: { color: '#589ec5', 'white-space': 'normal' },
        width: 20
    },
    {
        headerName: 'Email Id', field: 'UserEmail', sortable: true, filter: true, width: 80,
        cellRenderer(params) {
            return '<span title="' + params.value + '">' + params.value + '</span>';
        }
    },
    {
        headerName: 'First Name', field: 'FirstName', sortable: true, filter: true, width: 20,
        cellRenderer(params) {
            return '<span title="' + params.value + '">' + params.value + '</span>';
        }
    },
    {
        headerName: 'Last Name', field: 'LastName', sortable: true, filter: true, width: 20,
        cellRenderer(params) {
            return '<span title="' + params.value + '">' + params.value + '</span>';
        }
    },
    { headerName: 'Role', field: 'UserRole', sortable: true, filter: true, width: 10 },
    { headerName: 'Status', field: 'UserStatus', sortable: true, filter: true, width: 10 },
    {
        headerName: 'Categories', field: 'UserCategoriesList', sortable: true, filter: true, width: 50, autoHeight: true,
        cellStyle: { 'white-space': 'normal' },

        cellRenderer(params) {
            const a = document.createElement('div');
            if (params.value) {
                a.innerHTML = params.value;
                a.innerHTML = a.innerHTML.split(',').join('<br/>');
            }
            return a;
        },

     },
    {
        headerName: 'Modules', field: 'UserModuleList', sortable: true, filter: true, width: 50, autoHeight: true,
        cellStyle: { 'white-space': 'normal' },
        cellRenderer(params) {
            const a = document.createElement('div');
            if (params.value) {
                a.innerHTML = params.value;
                a.innerHTML = a.innerHTML.split(',').join('<br/>');
            }
            return a;
        },
    },
    { headerName: 'Sub Business', field: 'SubBusinessDesc', sortable: true, filter: true, width: 80 },
    { headerName: 'Cost Centre', field: 'CostCentreDesc', sortable: true, filter: true, width: 80 },
    { headerName: 'Action', cellRendererFramework: UserButtonActionComponent, width: 10, sortable: false, filter: false }
  ];
  public loading = false;
  subscriptions: Subscription[] = [];
  public gridOptions = {
    columnDetails: this.userHeaderDefs
  };
  public categoryMasterList: any;
  public moduleMasterList: any;
  public subBusinessMasterList: any;
  public costCentreMasterList: any;
  exportEventSubject: Subject<any> = new Subject<any>();

  constructor(
    private modalService: BsModalService,
    private usersService: UsersService,
    private metdataService: MetdataService,
    private singletonService: AppSingletonService,
    private dialogModel: MatDialog, private route: ActivatedRoute, private router: Router
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;

  }

  ngOnInit() {
    this.subscriptions.push(this.metdataService.metadataObservable.subscribe((recieved) => {
      if (recieved) {
        this.usersService.getMasters().subscribe(
          (result) => {
            this.categoryMasterList = result.masters.CategoryMaster;
            this.moduleMasterList = result.masters.ModuleMaster;
            this.subBusinessMasterList = result.masters.SubBusinessMaster;
            this.costCentreMasterList = result.masters.CostCentreMaster;
          },
          error => console.log('Error :: ' + error),
          () => {
            this.singletonService.setCategoryMasterList(this.categoryMasterList);
            this.singletonService.setModuleMasterList(this.moduleMasterList);
            this.singletonService.setSubBusinessMasterList(this.subBusinessMasterList);
            this.singletonService.setCostCentreMasterList(this.costCentreMasterList);
          }
        );
        this.categoryMasterList = this.singletonService.getCategoryMasterList();
        this.moduleMasterList = this.singletonService.getModuleMasterList();
        this.subBusinessMasterList = this.singletonService.getSubBusinessMasterList();
        this.costCentreMasterList = this.singletonService.getCostCentreMasterList();
        this.getUserData();
      }
    }));
  }

  getUserData() {
    this.loading = true;
    this.usersService.getUserData().subscribe((result: any) => {
      if (result != null) {
        result.users.filter(userElement => {
          let UserCategoryList: any;
          let UserModuleList: any;
          if (userElement.UserCategories || userElement.UserModules) {
            const userCategory = JSON.parse(userElement.UserCategories);
            const userModule = JSON.parse(userElement.UserModules);
            if (userElement.UserCategories && userElement.UserCategories !== 'null') {
              if (userCategory.Categories.length === 1 && userCategory.Categories[0] === 0) {
                UserCategoryList = 'All';
              } else {
                UserCategoryList = this.categoryMasterList.filter(masterEle =>
                  userCategory.Categories.some(userEle => masterEle.ID === userEle))
                  .map(item => item.Description).join(',');
              }
            }
            if (userElement.UserModules !== 'null') {
              if (userModule.Modules.length === 1 && userModule.Modules[0] === 0) {
                UserModuleList = 'All';
              } else {
                UserModuleList = this.moduleMasterList.filter(masterEle =>
                  userModule.Modules.some(userElem => masterEle.ID === userElem))
                  .map(item => item.Description).join(',');
              }
            }
          }
          userElement.SubBusinessDesc = null;
          userElement.CostCentreDesc = null;
          if (userElement.SubBusinessID >= 0) {
            const SubBusinessDesc = this.subBusinessMasterList.filter(masterEle => userElement.SubBusinessID === masterEle.ID
            ).map(item => item.Description);
            userElement.SubBusinessDesc = SubBusinessDesc[0];
          }
          if (userElement.CostCentreID >= 0) {
            const CostCentreDesc = this.costCentreMasterList.filter(masterEle => userElement.CostCentreID === masterEle.ID
            ).map(item => item.Description);
            userElement.CostCentreDesc = CostCentreDesc[0];
          }
          userElement.UserCategoriesList = UserCategoryList;
          userElement.UserModuleList = UserModuleList;
        });
      }
      this.loading = false;
      this.userData = result.users;
    },
      error => {
        this.loading = false;
      }
    );
  }

  onExport(type) {
    if (type === DownloadTypeEnum.Csv ) {
      const params = {
        columnKeys: AppConstantsHelper.userListHeader.map(item => item.field),
        fileName: AppConstantsHelper.excelUserListName
      };
      this.exportEventSubject.next(params);
    } else if (type === DownloadTypeEnum.Excel) {
      this.onExcelExport();
    }
  }

  onExcelExport() {
    const rows = this.userData.map((data) => {
      const row = [
        data.UserSSO,
        data.UserEmail,
        data.FirstName,
        data.LastName,
        data.UserRole,
        data.UserStatus,
        data.UserCategoriesList,
        data.UserModuleList,
        data.SubBusinessDesc,
        data.CostCentreDesc
      ];
      return row;
    });

    CommonFunctionsHelper.downloadExcel(AppConstantsHelper.excelUserListHeader, rows, AppConstantsHelper.excelUserListName);
  }

  /*
  onRowSelection(emittedEvent, template) {
    this.saveDisabled = true;
    this.resetValidationFields();
    this.isUpdate = true;
    this.userEditDetails = emittedEvent.event;
    this.copyUserDetails = JSON.parse(JSON.stringify(this.userEditDetails));
    this.selectedOptionName = this.chronosRoles.filter((role) => {
      return role.roleId === this.userEditDetails.ROLE_ID;
    })[0];
    this.selectedStatusName = this.chronosUserStatus.filter((status) => {
      return status.name === this.userEditDetails.STATUS;
    })[0];
    this.openModal(template);
  }

 */

  public ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  createUser() {
    this.simpleDialog = this.dialogModel.open(CreateEditUserComponent, {
      data: { isUpdate: false, entireUserData: this.userData },
      disableClose: false
    });

    this.simpleDialog.afterClosed().subscribe((result: any) => {
    if (result !== 'cancel') {
      this.getUserData();
    }
    this.simpleDialog = null;
    });
  }

  editUser(params: any) {
    console.log('user component edit');
    this.simpleDialog = this.dialogModel.open(CreateEditUserComponent, {
      data: { isUpdate: true, userData: params.data },
      disableClose: false
    });

    this.simpleDialog.afterClosed().subscribe((result: any) => {
      this.simpleDialog = null;
      if (result !== 'cancel') {
        this.router.navigate(['/admin/users']);
      }
    });
  }

}

