
import { Injectable } from '@angular/core';
import { AppSettings } from '../../../app.settings';
import { ApiProxy } from '../../../api.proxy';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  private baseUrl: string = AppSettings.microservices.UserMgmt_MicroService_BaseUrl;

  constructor(private apiProxy: ApiProxy) {}

  getUserData() {
    return this.apiProxy.get(this.baseUrl + 'userMgmt/fetchUsers');
  }

  updateUserData(data: any) {
    return this.apiProxy.post(this.baseUrl + 'userMgmt/updateUser', data);
  }

  createUserData(data: any) {
    return this.apiProxy.post(this.baseUrl + 'userMgmt/createUser', data);
  }
  deleteUser(data: any) {
    return this.apiProxy.post(this.baseUrl + 'userMgmt/deleteUser', data);
  }

  // This function used to get all Master table data
  public getMasters() {
    return this.apiProxy.get(this.baseUrl + 'masterMgmt/fetchMasters');
}

}
