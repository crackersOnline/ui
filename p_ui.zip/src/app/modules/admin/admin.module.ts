import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminGuard } from '../admin/app.admin.guard';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { UsersComponent } from './users/users.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FragmentsModule } from 'src/app/fragments/fragments.module';
import {
  MatIconModule,
  MatButtonModule,
  MatMenuModule,
  MatCardModule,
  MatSelectModule,
  MatDialogModule,
  MatFormFieldModule } from '@angular/material';
import { CommonProjectModule } from './../../common/common.module';
import { UserButtonActionComponent } from './users/user-button-action/user-button-action.component';

@NgModule({
  declarations: [
    AdminComponent,
    UsersComponent,
    UserButtonActionComponent
  ],
  imports: [
    CommonProjectModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    AdminRoutingModule,
    FragmentsModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatSelectModule,
    MatDialogModule,
    MatFormFieldModule,
    MatMenuModule,
    ModalModule.forRoot()
  ],
  providers: [AdminGuard],
  exports : [AdminRoutingModule ],
  entryComponents: [UserButtonActionComponent]
})
export class AdminModule { }
