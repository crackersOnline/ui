import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ToolsComponent } from './tools.component';


const childRoutes: Routes = [
  { path: '', component: ToolsComponent,
    // children: [
    //   { path: '', redirectTo: 'video', pathMatch: 'full' }
    // ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(childRoutes)],
  exports: [RouterModule]
})
export class ToolsRoutingModule { }
