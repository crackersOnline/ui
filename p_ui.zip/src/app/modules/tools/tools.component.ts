declare var initViz: any;
import { Component, AfterViewInit } from '@angular/core';
import { DataConstantsHelper, CommonFunctionsHelper } from '../../common/common.module';
import { Router } from '@angular/router';
import { AppSingletonService } from '../../app.singleton.service';
// import '../../../assets/scripts/tableau-initViz.js';
import { TableauViewService } from '../../services/tableau-view.service';

@Component({
  selector: 'app-tools',
  templateUrl: './tools.component.html'
})
export class ToolsComponent implements AfterViewInit {

  constructor(
    public tableauViewService: TableauViewService,
    private router: Router,
    private appSingletonService: AppSingletonService
    ) {
  }

  ngAfterViewInit() {
    this.tableauViewService.initViz();
  }
}
