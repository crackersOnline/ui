import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToolsRoutingModule } from './tools-routing.module';
import { FragmentsModule } from '../../fragments/fragments.module';
import { ToolsComponent } from './tools.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [ToolsComponent],
  imports: [
    FormsModule,
    CommonModule,
    ToolsRoutingModule,
    FragmentsModule,
    ModalModule.forRoot()
  ],
  exports : [ToolsRoutingModule]
})
export class ToolsModule { }
