declare var initViz: any;
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ReportTypeEnum } from 'src/app/common/models/app.enums';
import { SearchService } from 'src/app/modules/search/services/search.service';
import { TableauViewService } from '../../../services/tableau-view.service';
import { AppConstantsHelper } from 'src/app/common/helpers/app-constants.helper';

export interface ExpansionData {
  CatgID: number;
  Category: string;
  panelOpenStateParent: boolean;
  childNode?: [
    {
      SubCatgID: number;
      SubCategory: string;
      panelOpenStateChild: boolean;
      leafNode?: [{
        DashboardReportID?: number;
        DashboardReportName?: string;
        Metrics?: string;
        panelOpenStateLeaf?: boolean;
      }]
    }
  ];
}

@Component({
  selector: 'app-category-insight',
  templateUrl: './category-insight.component.html',
  styleUrls: ['./category-insight.component.scss']
})

export class CategoryInsightComponent implements OnInit {
  searchPanelCards: ExpansionData[] = [];
  public ReportTypeTableau = ReportTypeEnum.Tableau;
  public buttonLabel = AppConstantsHelper.insightByCategoryLabel;
  public expanedButtonName = this.buttonLabel[0].labelName;
  public icon = this.buttonLabel[0].icon;
  constructor(
    public tableauViewService: TableauViewService,
    private searchService: SearchService ) {
  }

  ngOnInit() {
    const inputData = { questionID: 0, type: false };
    this.searchService.getCategoryReports(inputData).subscribe((data: any) => {
      this.searchPanelCards = [];
      const parent: any[] = [];
      if (data.metadataMap) {
        data.metadataMap.forEach( (element, index, arr) => {
        if (index === 0 || (index > 0 && arr[index].CatgID !== arr[index - 1].CatgID)) {
          parent.push({
            CatgID: element.CatgID,
            Category: element.Category,
            panelOpenStateParent: false,
            childNode: [{
              SubCatgID: element.SubCatgID,
              SubCategory: element.SubCategory,
              panelOpenStateChild: false,
              leafNode: [{
                DashboardReportID: element.DashboardReportID,
                DashboardReportName: element.DashboardReportName,
                Metrics: element.Metrics,
                ReportType: element.ReportType,
                ReportLink: element.ReportLink,
                panelOpenStateLeaf: false
              }]
            }]
          });
        }
        if (index > 0 && (arr[index].CatgID === arr[index - 1].CatgID && arr[index].SubCatgID !== arr[index - 1].SubCatgID)) {
          parent[parent.length - 1].childNode.push({
            SubCatgID: element.SubCatgID,
            SubCategory: element.SubCategory,
            leafNode: [{
              DashboardReportID: element.DashboardReportID,
              DashboardReportName: element.DashboardReportName,
              Metrics: element.Metrics,
              ReportType: element.ReportType,
              ReportLink: element.ReportLink
            }]
          });
        //  j++;
        }
        if (index > 0 && arr[index].CatgID === arr[index - 1].CatgID && (arr[index].SubCatgID === arr[index - 1].SubCatgID)) {
          const childNodeLength = parent[parent.length - 1].childNode.length;
          parent[parent.length - 1].childNode[childNodeLength - 1].leafNode.push({
            DashboardReportID: element.DashboardReportID,
            DashboardReportName: element.DashboardReportName,
            Metrics: element.Metrics,
            ReportType: element.ReportType,
            ReportLink: element.ReportLink
          });
        }
      });
        this.searchPanelCards = parent;
      }
    });
  }

  getReport(report, containerDivID, container) {
    this.searchService.onClickReport(report, containerDivID);
    container.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }

  togglePanel(expanedButtonName) {
    let status;
    if (expanedButtonName === this.buttonLabel[0].labelName) {
      status = true;
      this.expanedButtonName = this.buttonLabel[1].labelName;
      this.icon = this.buttonLabel[1].icon;
    } else {
      status = false;
      this.expanedButtonName = this.buttonLabel[0].labelName;
      this.icon = this.buttonLabel[0].icon;
    }
    this.searchPanelCards.forEach(parent => {
      parent.panelOpenStateParent = status;
      parent.childNode.forEach(child => {
        child.panelOpenStateChild = status;
        child.leafNode.forEach(leaf => {
          leaf.panelOpenStateLeaf = status;
        });
      });
    });
  }

expandCollopseCheck(status: boolean, Type: string, CatgID: number, SubCatgID?: any, DashboardReportID?: any) {
  const index = this.searchPanelCards.findIndex(item => item.CatgID === CatgID);
  if (Type === this.buttonLabel[2].parent) {
    this.searchPanelCards[index].panelOpenStateParent = status;
  } else if (Type === this.buttonLabel[2].child) {
    const childIndex = this.searchPanelCards[index].childNode.findIndex(item => item.SubCatgID === SubCatgID);
    this.searchPanelCards[index].childNode[childIndex].panelOpenStateChild = status;
  } else if (Type === this.buttonLabel[2].leaf) {
    const childIndex = this.searchPanelCards[index].childNode.findIndex(item => item.SubCatgID === SubCatgID);
    const leafIndex = this.searchPanelCards[index].childNode[childIndex].leafNode.findIndex(item =>
       item.DashboardReportID === DashboardReportID);
    this.searchPanelCards[index].childNode[childIndex].leafNode[leafIndex].panelOpenStateLeaf = status;
  }
  if (this.searchPanelCards.some(item => item.panelOpenStateParent === true)) {
    this.expanedButtonName = this.buttonLabel[1].labelName;
    this.icon = this.buttonLabel[1].icon;
  } else {
    this.expanedButtonName =  this.buttonLabel[0].labelName;
    this.icon = this.buttonLabel[0].icon;
  }
}


}
