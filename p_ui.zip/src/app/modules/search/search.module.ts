import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchRoutingModule } from './search-routing.module';
import { FragmentsModule } from '../../fragments/fragments.module';
import { SearchComponent } from './search.component';
import { SearchHeaderComponent } from './search-header/search-header.component';
import { SearchHomeComponent } from './home/searchHome.component';
import { CategoryInsightComponent } from './category-insight/category-insight.component';
import { AllInsightComponent } from './all-insight/all-insight.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatPaginatorModule } from '@angular/material/paginator';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AllInsightPanelComponent } from 'src/app/fragments/functional/all-insight-panel/all-insight-panel.component';
import { MatIconModule, MatButtonModule, MatExpansionModule } from '@angular/material';

@NgModule({
  declarations: [
    SearchComponent,
    SearchHeaderComponent,
    SearchHomeComponent,
    CategoryInsightComponent,
    AllInsightComponent,
    AllInsightPanelComponent
  ],
  imports: [
    FormsModule,
    CommonModule,
    MatIconModule,
    SearchRoutingModule,
    FragmentsModule,
    MatGridListModule,
    MatCardModule,
    FlexLayoutModule,
    MatIconModule,
    MatButtonModule,
    MatExpansionModule,
    MatPaginatorModule,
    ModalModule.forRoot()
  ],
  exports : [SearchRoutingModule]
})
export class SearchModule { }
