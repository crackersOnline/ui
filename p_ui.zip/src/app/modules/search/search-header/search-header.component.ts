/**
 * Header for the app
 * Logo, App Name, Tab - form Names, User Menu
 * Form Names from HttpClient Call
 * Local Storage is retrieved for the current User's First Name
 * User Menu - Dropdown on click of User's First Name
 * Dropdown with Support (audienceanalyzer.dev@nbcuni.com) and
 * Logout - Logs out of the app by removing the local storages (SSO ID, FirstName)
 */

import { Component, OnInit, OnDestroy, Output, ViewChild, HostListener } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription, Subject } from 'rxjs';
import { SearchService } from '../services/search.service';
import {
  MetdataService,
  UsageTrackingService,
  UsageTrackingModel,
  UsageTrackingActionType
} from '../../../common/common.module';
import { AutocompleteFilterComponent } from 'src/app/fragments/functional/autocomplete-filter/autocomplete-filter.component';
import { JwtTokenService } from './../../../common/common.module';

@Component({
  selector: 'app-search-header',
  templateUrl: './search-header.component.html',
  styleUrls: ['./search-header.component.scss']
})

export class SearchHeaderComponent implements OnInit, OnDestroy {
  // Initialize
  public live: string;
  public dvr: string;
  public liveAd: string;
  public dvrAd: string;
  public datesList: any;
  public formList: any[];
  public formNameFilter: any[];
  public selectedFormName; public selectedForm: number;
  public toggleNavbar: boolean;
  public isOpenLogout: boolean; public envFooterConstant: any;
  public userFirstName: string;
  public options: Array<object> = [];
  public condition = true;
  public questionId: any;
  public questionLabel = '';

  // Subscription
  public formNamesSubscription: Subscription;
  public headerSubscribe: Subject<void> = new Subject<void>();
  subscriptions: Subscription[] = [];

  @ViewChild('reset', { static: true }) childComponent: AutocompleteFilterComponent;

  @HostListener('document:click', ['$event'])

  onClickEvent(event: MouseEvent) {
    const target: any = event.target;
    if (target.id === 'logo_home') {
      this.questionId = '';
      this.questionLabel = '';
    }
  }

  constructor(
    private router: Router,
    public metdataService: MetdataService,
    private searchService: SearchService,
    private usageTrackingService: UsageTrackingService) {
  }

  public ngOnInit() {
    this.subscriptions.push(this.metdataService.metadataObservable.subscribe((recieved) => {
      if (recieved) {
        this.fetchQuestions();
      }

    }));
  }

  public fetchQuestions() {
    this.searchService.getQuestions().subscribe(data => {
      this.options = data.questions;
    });
  }

  getQuestionIdChangedHandler(event: any) {
    this.questionId = event.questionID;
    if (this.router.url !== '/search' && event.type === true) {
      this.router.navigate(['']);
    }
    this.usageTrackingService.log(new UsageTrackingModel(UsageTrackingActionType.SearchQuestion,
      this.questionId,
      null,
      null,
      null));
    this.searchService.getCategoryReports(event).subscribe((data: any) => {
      if (data) {
        this.searchService.clickEvent({ questionId: this.questionId, data: data.metadataMap });
      }
    });
  }

  public goToHome() {
    this.router.navigate(['/search']);
  }

  toggle(event) {
    this.questionLabel = '';
    this.condition = !this.condition;
    if (this.questionId !== undefined || this.questionId !== '') {
      this.options.forEach((obj: any) => {
        if (obj.QuestionID === this.questionId) {
          this.questionLabel = obj.QuestionTitle;
        }
      });
    } else {
      this.questionLabel = '';
    }
  }

  public ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  clear() {
    this.questionId = '';
    this.childComponent.myControl.reset();
    this.searchService.clickEvent('');
  }

  allDashBoardsClick() {
    this.usageTrackingService.log(new UsageTrackingModel(UsageTrackingActionType.AllDashboards,
      null,
      null,
      null,
      null));
    this.clear();
  }
}
