import { Injectable } from '@angular/core';
// import { SearchModule } from '../search.module';
import { ApiProxy } from '../../../api.proxy';
import { BehaviorSubject, of, Subject, Observable } from 'rxjs';
import { AppSettings } from 'src/app/app.settings';
import { AppConstantsHelper } from 'src/app/common/helpers/app-constants.helper';
import { ReportTypeEnum } from 'src/app/common/models/app.enums';
import { TableauViewService } from 'src/app/services/tableau-view.service';
import { environment } from 'src/environments/environment';

@Injectable({
    //   providedIn: SearchModule
    providedIn: 'root'
})

export class SearchService {
    private eventSource = new BehaviorSubject(null);
    metadataMapEmit$ = this.eventSource.asObservable();
    private baseUrl: string = AppSettings.microservices.search_MicroService_BaseUrl;
    private serviceUrl = AppConstantsHelper.serviceUrl;

    constructor(
        private apiProxy: ApiProxy,
        private tableauViewService: TableauViewService) { }

    /**
     * getQuestions return options
     * @param: {}
     */
    getQuestions() {
        return this.apiProxy.get(this.baseUrl + this.serviceUrl.searchFetchQuestion);
    }

    clickEvent(event: any) {
        this.eventSource.next(event);
    }

    onClickReport(report: any, containerDivID: any) {
        if (report.ReportType) {
            if (report.ReportType === ReportTypeEnum.Tableau && report.ReportLink !== '') {
                //  this.tableauViewService.initViz();
                const containerDiv = 'vizContainer' + containerDivID;
                const reportlink = environment.reportLinkBaseUrl + report.ReportLink;
                this.tableauViewService.loadingIndicatorObserver(`#${containerDiv}`);
                this.tableauViewService.loadTableau(containerDiv, reportlink);
            } else {
                this.doDownload(report.ReportLink);
            }
        }
    }

    doDownload(fileName: string) {
        return this.apiProxy.post(this.baseUrl + this.serviceUrl.downloadDashboardReport, { fileName }).subscribe(
            (response: any) => {
                const a = document.createElement('a');
                const myBufferData = new Uint8Array(response.Body.data);
                const blob = new Blob([myBufferData], { type: response.ContentType });
                a.href = window.URL.createObjectURL(blob);
                a.download = response.FileName;
                a.click();
            });
    }

    getCategoryReports(question: object) {
        return this.apiProxy.post(this.baseUrl + this.serviceUrl.searchFetchMetadataByQuestionID, question);
    }

    /**
     * getKPI return KPI's
     * @param: {}
     */
    fetchKPI() {
        // return of([
        //     'https://sharedtableaudev2.inbcu.com/#/site/FacilitiesAnalytics/views/Dashboard6/Dashboard?:iid=2&:toolbar=no',
        //     'https://sharedtableaudev2.inbcu.com/#/site/FacilitiesAnalytics/views/Dashboard5/Dashboard?:iid=1&:toolbar=no',
        //     'https://sharedtableaudev2.inbcu.com/#/site/FacilitiesAnalytics/views/Dashboard4/Dashboard?:iid=3&:toolbar=no'
        // ]);
        return this.apiProxy.get(this.baseUrl + this.serviceUrl.fetchKPI);
    }
}
