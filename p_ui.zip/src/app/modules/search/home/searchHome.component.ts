import { Component, OnInit, OnDestroy } from '@angular/core';
import { SearchService } from '../services/search.service';
import { Subscription } from 'rxjs';
import { TableauViewService } from '../../../services/tableau-view.service';
import { Router, NavigationEnd } from '@angular/router';
import {
  MetdataService,
  UsageTrackingService,
  UsageTrackingModel,
  UsageTrackingActionType
} from './../../../common/common.module';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-search-home',
  templateUrl: './searchHome.component.html',
  styleUrls: ['./searchHome.component.scss']
})

export class SearchHomeComponent implements OnInit, OnDestroy {
  searchPanelCards: Array<object> = [];
  subscriptions: Subscription[] = [];
  public kpis: Array<any> = [];
  public allKPIs: Array<any> = [];
  public questionId = null;
  public showViz = false;
  noNavigation = false;


  constructor(
    private searchService: SearchService,
    public tableauViewService: TableauViewService,
    private router: Router,
    private metdataService: MetdataService,
    private usageTrackingService: UsageTrackingService) {
    this.subscriptions.push(this.router.events.subscribe((e: any) => {
      // If it is a NavigationEnd event re-initialize the parts of component OR reset the properties
      if (e instanceof NavigationEnd) {
        if (this.noNavigation) {
          this.noNavigation = false;
          return;
        } else {
          this.resetProperties();
        }
      }
    }));
  }

  ngOnInit() {
    this.subscriptions.push(this.searchService.metadataMapEmit$.subscribe(data => {
      this.searchPanelCards = [];
      if (data) {
        this.questionId = data.questionId;
        this.searchPanelCards = data.data;
        this.showViz = false;
        setTimeout(() => {
          this.tableauViewService.loadingIndicatorObserver('#vizContainer');
        }, 1000);
      }
    }));

    if (!this.searchPanelCards.length) {
      this.subscriptions.push(this.metdataService.metadataObservable.subscribe((recieved) => {
        if (recieved) {
          this.usageTrackingService.log(new UsageTrackingModel(UsageTrackingActionType.KPIDashboard,
            null,
            null,
            null,
            null));
          this.fetchKPI();
        }
      }));
    }
  }

  getReport(report, containerDivID, container) {
    this.showViz = true;
    this.noNavigation = true;
    this.usageTrackingService.log(new UsageTrackingModel(UsageTrackingActionType.ReportLinkClick,
      this.questionId,
      report.CatgID,
      report.SubCatgID,
      report.DashboardReportID));
    setTimeout(() => {
      this.searchService.onClickReport(report, containerDivID);
      container.scrollIntoView({ block: 'start', behavior: 'smooth' });
    }, 100);
  }

  /* Fetch KPI from Node Api */
  fetchKPI() {
    this.searchService.fetchKPI().subscribe(data => {
      this.kpis = data.kpis;

      if (!this.searchPanelCards.length) {
        this.loadKPI();
      }
    });
  }

  /* On onSameUrlNavigation reset component properties */
  resetProperties() {
    // Set default values and re-fetch any data you need.
    this.searchPanelCards.length = 0;
    this.loadKPI();
  }

  /* wait for html to be ready to hold tableau dashboard and then load tableau dashboard */
  loadKPI() {
    setTimeout(() => {
      this.tableauViewService.loadingIndicatorObserver('#kpi0');
      if (!this.searchPanelCards.length) { // If searchPanelCards are loaded, do not render KPI dashboard
        this.kpis = [this.kpis[0]];
        if (this.kpis[0]) {
          this.kpis.forEach((link: any, index) => {
            this.tableauViewService.loadTableau('kpi' + index, link.ReportLink, 'KPI');
          });
        }
      }
    }, 500);
  }

  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }
}
