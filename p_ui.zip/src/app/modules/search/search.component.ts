import { Component, AfterViewInit } from '@angular/core';
import { DataConstantsHelper, CommonFunctionsHelper } from '../../common/common.module';
import { Router } from '@angular/router';
import { AppSingletonService } from '../../app.singleton.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements AfterViewInit {

  constructor(private router: Router, private appSingletonService: AppSingletonService) {
  }

  ngAfterViewInit() {
    // this.tabData = DataConstantsHelper.tabOptions.programMapping;
  }

}
