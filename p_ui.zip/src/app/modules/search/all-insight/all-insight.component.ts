import { Component, OnInit, TemplateRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { SearchService } from '../services/search.service';

@Component({
  selector: 'app-all-insight',
  templateUrl: './all-insight.component.html',
  styleUrls: ['./all-insight.component.scss']
})

export class AllInsightComponent implements OnInit {

  constructor() {}
    ngOnInit() {}
}
