import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from './search.component';
import { SearchHomeComponent } from './home/searchHome.component';
import { CategoryInsightComponent } from './category-insight/category-insight.component';
import { AllInsightComponent } from './all-insight/all-insight.component';

const childRoutes: Routes = [
  { path: '', component: SearchComponent,
    // children: [
    //   { path: '', redirectTo: 'video', pathMatch: 'full' }
    // ]
    children: [
      { path: '', component: SearchHomeComponent },
      { path: 'categoryInsight', component: CategoryInsightComponent },
      { path: 'allInsight', component: AllInsightComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(childRoutes)],
  exports: [RouterModule]
})
export class SearchRoutingModule { }
