/**
 * Autocomplete filter for searching within a set of data
 */

import { Component, OnInit, Input, Output, EventEmitter, OnChanges, HostListener } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { SearchService } from '../../../modules/search/services/search.service';
export interface Questions {
  QuestionID: number;
  QuestionTitle: string;
  QuestionDetails: string;
}


@Component({
  selector: 'app-autocomplete-filter',
  templateUrl: './autocomplete-filter.component.html',
  styleUrls: ['./autocomplete-filter.component.scss']
})
export class AutocompleteFilterComponent implements OnInit, OnChanges {

  public myControl = new FormControl();
    @Input() options: Questions[];
    @Output() questionIdEmit = new EventEmitter<object>();
    filteredOptions: Observable<Questions[]>;

    @HostListener('document:click', ['$event'])
    onClickEvent(event: MouseEvent) {
        const target: any = event.target;
        if (target.id === 'logo_home') {
          this.clearSearch();
        }
    }

    constructor() {

    }

    ngOnInit() {
    }

    ngOnChanges() {
      if (this.options) {
        this.filteredOptions = this.myControl.valueChanges
        .pipe(
          startWith(''),
          map(value => value ? this._filter(value) : this.options.slice())
        );
      }
    }

    private _filter(value: any): Questions[] {
      const filterValue = value.QuestionTitle || value;

      return this.options.filter(option => option.QuestionTitle.toLowerCase().includes(filterValue.toLowerCase()));
    }

    public onQuestionClick(option: Questions) {
      this.questionIdEmit.emit({ questionID: option.QuestionID, type: true});
    }

    public clearSearch() {
        this.myControl.reset('');
    }

    displayFn(filterBy: Questions) {
      return (filterBy) ? filterBy.QuestionTitle : '';
    }
}
