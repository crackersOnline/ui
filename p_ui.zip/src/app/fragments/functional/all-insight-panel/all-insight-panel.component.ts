import { Component, OnInit } from '@angular/core';
import { SearchService } from 'src/app/modules/search/services/search.service';
import { AppConstantsHelper } from 'src/app/common/helpers/app-constants.helper';
import { CommonFunctionsHelper } from 'src/app/common/common.module';
import {
  UsageTrackingService,
  UsageTrackingModel,
  UsageTrackingActionType
} from 'src/app/common/common.module';

@Component({
  selector: 'app-all-insight-panel',
  templateUrl: './all-insight-panel.component.html',
  styleUrls: ['./all-insight-panel.component.scss']
})

export class AllInsightPanelComponent implements OnInit {
  public searchPanelCards: Array<object> = [];
  public insightLabel = AppConstantsHelper.insightLabel;
  public pageSize = AppConstantsHelper.numberOfReportsPerPanelPage;
  constructor(
    private searchService: SearchService,
    private usageTrackingService: UsageTrackingService) { }

  ngOnInit() {
    const inputData = { questionID: 0, type: false };
    this.searchService.getCategoryReports(inputData).subscribe((data: any) => {
      this.searchPanelCards = [];
      const parent: any[] = [];
      if (data.metadataMap) {
        data.metadataMap.forEach((element, index, arr) => {
          if ((index === 0) || (index > 0 && element.CatgID !== arr[index - 1].CatgID) ||
            index > 0 && element.CatgID === arr[index - 1].CatgID && (element.SubCatgID !== arr[index - 1].SubCatgID)) {
            parent.push({
              CatgID: element.CatgID,
              Category: element.Category,
              SubCatgID: element.SubCatgID,
              SubCategory: element.SubCategory,
              leafNode: [{
                DashboardReportID: element.DashboardReportID,
                DashboardReportName: element.DashboardReportName,
                Metrics: element.Metrics,
                ReportType: element.ReportType,
                ReportLink: element.ReportLink
              }]
            });
          } else if (index > 0 && element.CatgID === arr[index - 1].CatgID && (element.SubCatgID === arr[index - 1].SubCatgID)) {
            parent[parent.length - 1].leafNode.push({
              DashboardReportID: element.DashboardReportID,
              DashboardReportName: element.DashboardReportName,
              Metrics: element.Metrics,
              ReportType: element.ReportType,
              ReportLink: element.ReportLink
            });
          }
        });
        parent.forEach(obj => {
          CommonFunctionsHelper.sortArrayBasedOnAStringValuedProp(obj.leafNode, 'DashboardReportName', 'asc');
          this.getValuesAsPerPageNumber(obj, { pageIndex: 0 });
        });
        this.searchPanelCards = parent;
      }
    });
  }

  getReport(report, containerDivID, container, panelCard) {
    this.usageTrackingService.log(new UsageTrackingModel(UsageTrackingActionType.ReportLinkClick,
      null,
      panelCard.CatgID,
      panelCard.SubCatgID,
      report.DashboardReportID));
    this.searchService.onClickReport(report, containerDivID);
    container.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }
  getValuesAsPerPageNumber(obj: any, event) {
    const copy = JSON.parse(JSON.stringify(obj.leafNode));
    obj.paginatedLeafNode = copy.slice(event.pageIndex * this.pageSize,
      (event.pageIndex * this.pageSize) + this.pageSize);
  }

  getDataSetAsPerDataSize(obj) {
    if (obj.leafNode.length > 4) {
      return obj.paginatedLeafNode;
    } else {
      return obj.leafNode;
    }
  }

}
