import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-delete-dialog',
  templateUrl: './delete-dialog.component.html',
  styles: [
    `.example-button-row {
      display: table-cell;
      float: right;
    }
    .example-button-row button {
      display: table-cell;
      margin-right: 8px;
    }
    `
  ]
})

export class DeleteDialogComponent implements OnInit {

  constructor(
    private dialogRef: MatDialogRef<DeleteDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  ngOnInit() {}

  delete() {
    this.dialogRef.close(true);
  }

  close() {
      this.dialogRef.close(false);
  }
}
