/**
 * Footer for the app
 * Logo, App Version, App Environment, user SSO ID
 * Final Dates from HttpClient Call
 * Local Storage is retrieved for the current User's SSO ID
 */

import { Component, OnInit, OnDestroy } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { Subscription, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-footer',
  templateUrl: './app-footer.component.html',
  styleUrls: ['./app-footer.component.scss']
})
export class AppFooterComponent implements OnInit, OnDestroy {

  public envConstant: any;
  public userSSO: any;
  public live: string;
  public dvr: string;
  public liveAd: string;
  public dvrAd: string;
  public datesList: any;

  // Subscription
  public finalDatesSubscription: Subscription;
  public footerSubscribe: Subject<void> = new Subject<void>();

  constructor() {
    this.envConstant = environment.constants;
    this.userSSO = localStorage.getItem('currentUser').replace(/"/g, '');
  }

  ngOnInit() {
  }
  // /**
  //  * @method: ngOnInit()
  //  * @param: {}
  //  * @returns: {}
  //  * @description: Set the Final Dates on Load
  //  * Subscribe the service in form.service.ts getFinalDates()
  // */
  // ngOnInit() {
  //   // Final Dates List on page load
  //   this.finalDatesSubscription = this.navBarService.getFinalDates().pipe(takeUntil(this.footerSubscribe)).subscribe(
  //     (resp_final_dates) => {
  //        this.datesList = resp_final_dates;
  //        this.live = this.dateSvc.formatFormDates(this.datesList.latest_live_complete_date);
  //        this.dvr = this.dateSvc.formatFormDates(this.datesList.latest_dvr_complete_date);
  //        this.liveAd = this.dateSvc.formatFormDates(this.datesList.latest_live_ad_complete_date);
  //        this.dvrAd =  this.dateSvc.formatFormDates(this.datesList.latest_dvr_ad_complete_date);
  //     },
  //     error => {
  //         // console.log('Final Dates Error', error);
  //     });
  // }

  // /**
  //  * @method: ngOnDestroy()
  //  * @param: {}
  //  * @returns: {}
  //  * @description: Unsubscribe services
  // */
  // public ngOnDestroy() {
  //   this.footerSubscribe.next();
  //   this.footerSubscribe.complete();
  // }
  ngOnDestroy() {
  }
}
