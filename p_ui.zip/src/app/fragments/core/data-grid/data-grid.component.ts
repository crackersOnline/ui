import { Component, OnInit, Input, EventEmitter, Output, HostListener, ViewChild, ElementRef } from '@angular/core';
import { GridOptions } from 'ag-grid-community';
import { Subject } from 'rxjs';
import {CommonFunctionsHelper, AppConstantsHelper } from '../../../common/common.module';
import { DownloadTypeEnum } from '../../../common/models/app.enums';

@Component({
  selector: 'app-data-grid',
  templateUrl: './data-grid.component.html'
})

export class DataGridComponent implements OnInit {
  @Output() rowselected: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('eGrid', { read: ElementRef, static: false }) eGrid: ElementRef;
  public gridOptions: GridOptions;
  public overlayNoRowsTemplate;
  public defaultColDef;
  public columnApi;

  @Input() sizeColumnsToFit: boolean;
  @Input()
  set options(value: any) {
    if (value) {
      this.columnHeaders = value.columnDetails;
      this.loading = true;
      this.overlayNoRowsTemplate = '<span ' +
      'style="padding: 10px; font-size: 1.7em; background-color: rgba(255,255,255,0.3); z-index:9999; ">' +
      'Please wait while your rows are loading</span>';
      if (this.gridOptions === undefined) {
        this.defaultColDef = {
          resizable: true
        };
        this.gridOptions = {
          enableSorting: true,
          suppressMenuHide: true,
          enableFilter: true,
          columnDefs: this.columnHeaders,
          onGridReady: () => {
            this.columnApi =  this.gridOptions.columnApi;
            this.gridOptions.api.setColumnDefs(this.columnHeaders);
            this.gridOptions.api.setHeaderHeight(65);
            this.gridOptions.api.resetRowHeights();
            if (this.sizeColumnsToFit) {
              this.gridOptions.api.sizeColumnsToFit();
            }
          }
        };
      }
      if (this.gridOptions.api !== undefined) {
        this.gridOptions.api.setColumnDefs(this.columnHeaders);
        this.gridOptions.api.setHeaderHeight(65);
        this.gridOptions.api.resetRowHeights();
      }

    }
  }
  public columnHeaders: any;
  public loading: any;
  @Input()
  set data(value: any[]) {
    if (value) {
      this.rowData = value;
    }
  }

  public rowData = [];
  public style = '';
  @Input() exportEvent: Subject<any>;
  public excelExportData = [];


  constructor() {

   }

  ngOnInit() {
    this.exportEvent.subscribe((event)  => {
      this.onBtExport(event);
    });
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (this.gridOptions.api) {
      this.gridOptions.api.setColumnDefs(this.columnHeaders);
      this.gridOptions.api.resetRowHeights();
      if (this.sizeColumnsToFit) {
        this.gridOptions.api.sizeColumnsToFit();
      }
    }
  }

  onBtExport(params) {
    this.gridOptions.api.exportDataAsCsv(params);
  }

  onRowSelected(event) {
    console.log(event.data);
    this.rowselected.emit({ isUpdate: true, userData: event.data });
  }

  autoSizeAll(skipHeader)  {
 // If you need to resize specific columns
 const allColIds = this.columnApi.getAllColumns()
 .map(column => column.colId);
 this.columnApi.autoSizeColumns(allColIds, skipHeader);
  }




/*
  onBtExport(extn) {
    if (extn === DownloadTypeEnum.Csv ) {
      const params = {
        columnKeys: AppConstantsHelper.userListHeader.map(item => item.field),
        fileName: AppConstantsHelper.excelUserListName
      };
      this.gridOptions.api.exportDataAsCsv(params);
    }
    if (extn === DownloadTypeEnum.Excel) {
      this.onExcelExport();
    }
  }

onExcelExport() {
    const rows = this.rowData.map((data) => {
      const row = [
        data.UserSSO,
        data.UserEmail,
        data.FirstName,
        data.LastName,
        data.UserRole,
        data.UserStatus,
        data.UserCategoriesList,
        data.UserModuleList,
        data.SubBusinessDesc,
        data.CostCentreDesc
      ];
      return row;
    });
    CommonFunctionsHelper.downloadExcel(AppConstantsHelper.excelUserListHeader, rows, AppConstantsHelper.excelUserListName);
  }
*/
}
