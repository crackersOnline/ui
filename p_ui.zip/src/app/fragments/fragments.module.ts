import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AgGridModule } from 'ag-grid-angular';
import { ExpansionPanelComponent } from './functional/expansion-panel/expansion-panel.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule, MatInputModule, MatIconModule, MatButtonModule } from '@angular/material';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
import { MatAutocompleteModule } from '@angular/material';
import { AutocompleteFilterComponent } from './functional/autocomplete-filter/autocomplete-filter.component';
import { DataGridComponent } from './core/data-grid/data-grid.component';
import { DeleteDialogComponent } from './core/delete-dialog/delete-dialog.component';

@NgModule({
  declarations: [
    ExpansionPanelComponent,
    AutocompleteFilterComponent,
    DataGridComponent,
    DeleteDialogComponent
  ],

  imports: [
    RouterModule,
    CommonModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    FormsModule,
    ReactiveFormsModule,
    AgGridModule.withComponents([]),
    MatIconModule,
    MatButtonModule
  ],
  providers: [
   //  { provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: { appearance: 'fill' } }
  ],
  exports: [
    ExpansionPanelComponent,
    AutocompleteFilterComponent,
    DataGridComponent,
    DeleteDialogComponent
  ],
  entryComponents: [DeleteDialogComponent]

})
export class FragmentsModule { }
