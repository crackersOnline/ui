import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatFormFieldModule, MatIconModule } from '@angular/material';
import { MatMenuModule } from '@angular/material/menu';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { AppFooterComponent } from './fragments/core/app-footer/app-footer.component';
import { AppUnauthComponent } from './fragments/core/app-unauth/app-unauth.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpErrorInterceptor } from './http.interceptor';
import { AppErrorHandler } from './error.handler';
import { AuthManager } from './app.auth.manager';
import { AlwaysAuthGuard } from './app.auth.guard';
import { CreateEditUserComponent } from '../app/modules/admin/users/create-edit-user/create-edit-user.component';
import { SelectCheckAllComponent } from '../app/modules/admin/users/select-check-all.component';

import { CommonProjectModule } from './common/common.module';
import {
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatDialogModule,
  MatDividerModule,
  MatRadioModule,
  MatSelectModule,
  MatToolbarModule
} from '@angular/material';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { FragmentsModule } from './fragments/fragments.module';

@NgModule({
  declarations: [
    AppComponent,
    AppFooterComponent,
    AppUnauthComponent,
    CreateEditUserComponent,
    SelectCheckAllComponent
  ],
  imports: [
    FragmentsModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FlexLayoutModule,
    MatFormFieldModule,
    MatIconModule,
    MatMenuModule,
    DeviceDetectorModule.forRoot(),
    HttpClientModule,
    MatCardModule,
    MatCheckboxModule,
    MatDialogModule,
    MatSelectModule,
    MatRadioModule,
    MatToolbarModule,
    MatButtonModule,
  MatButtonToggleModule,
  MatDividerModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    CommonProjectModule
  ],
  providers: [
    AuthManager,
    AlwaysAuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true
    },
    {
      provide: ErrorHandler,
      useClass: AppErrorHandler
    }
  ],
  exports: [
    CreateEditUserComponent,
    SelectCheckAllComponent,
    MatButtonModule
  ],
  bootstrap: [AppComponent],
  entryComponents: [CreateEditUserComponent]
})
export class AppModule { }
