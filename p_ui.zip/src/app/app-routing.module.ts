import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthManager } from './app.auth.manager';
import { AlwaysAuthGuard } from './app.auth.guard';

const routes: Routes = [
            {
                path: 'error',
                loadChildren: './modules/error/error.module#ErrorModule'
            },
            { path: 'search',
              loadChildren: './modules/search/search.module#SearchModule',
              resolve: [AuthManager]
            },
            {
              path: '',
              redirectTo: 'search',
              pathMatch: 'full'
            },
            { path: 'admin',
              loadChildren: './modules/admin/admin.module#AdminModule',
              resolve: [AuthManager],
              canActivate: [AlwaysAuthGuard]
            }
          ];

@NgModule({
  imports: [RouterModule.forRoot(routes, {onSameUrlNavigation: 'reload'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
